import {
  MatDivider,
  MatDividerModule
} from "./chunk-JOAUHDQ4.js";
import "./chunk-7CA54YE4.js";
import "./chunk-4Q3EBFJU.js";
import "./chunk-M3HR6BUY.js";
import "./chunk-ZWATK3BN.js";
import "./chunk-FDZLQ5GF.js";
import "./chunk-DW6BKJDM.js";
import "./chunk-HRT7DAZ6.js";
import "./chunk-DVUYKZZ3.js";
import "./chunk-PEBH6BBU.js";
import "./chunk-WPM5VTLQ.js";
import "./chunk-4S3KYZTJ.js";
import "./chunk-WDMUDEB6.js";
export {
  MatDivider,
  MatDividerModule
};
