import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  MatDivider,
  MatDividerModule
} from "./chunk-E724QCIO.js";
import "./chunk-MFLKSTMO.js";
import "./chunk-2P75Y4GK.js";
import "./chunk-3BRDVZJE.js";
import "./chunk-EPVMHDTV.js";
import "./chunk-HJTKKQ3X.js";
import "./chunk-U34XVKUL.js";
import "./chunk-3DLGHKM2.js";
import "./chunk-NUVWF767.js";
import "./chunk-ZUJ64LXG.js";
import "./chunk-XCIYP5SE.js";
import "./chunk-OYTRG5F6.js";
import "./chunk-YHCV7DAQ.js";
export {
  MatDivider,
  MatDividerModule
};
