import { createRequire } from 'module';const require = createRequire(import.meta.url);
import "./chunk-HJTKKQ3X.js";
import {
  BidiModule,
  DIR_DOCUMENT,
  Dir,
  Directionality
} from "./chunk-U34XVKUL.js";
import "./chunk-3DLGHKM2.js";
import "./chunk-NUVWF767.js";
import "./chunk-ZUJ64LXG.js";
import "./chunk-XCIYP5SE.js";
import "./chunk-OYTRG5F6.js";
import "./chunk-YHCV7DAQ.js";
export {
  BidiModule,
  DIR_DOCUMENT,
  Dir,
  Directionality
};
