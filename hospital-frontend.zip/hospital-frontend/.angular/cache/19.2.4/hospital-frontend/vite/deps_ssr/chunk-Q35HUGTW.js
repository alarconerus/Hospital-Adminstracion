import { createRequire } from 'module';const require = createRequire(import.meta.url);
import {
  require_cjs
} from "./chunk-ZUJ64LXG.js";
import {
  require_operators
} from "./chunk-XCIYP5SE.js";
import {
  __toESM
} from "./chunk-YHCV7DAQ.js";

// node_modules/@angular/cdk/fesm2022/observers.mjs
var import_rxjs = __toESM(require_cjs(), 1);
var import_operators = __toESM(require_operators(), 1);
//# sourceMappingURL=chunk-Q35HUGTW.js.map
