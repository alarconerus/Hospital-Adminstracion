import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ListarBuscarHospitalComponent } from './listar-buscar-hospital.component';

describe('ListarBuscarHospitalComponent', () => {
  let component: ListarBuscarHospitalComponent;
  let fixture: ComponentFixture<ListarBuscarHospitalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ListarBuscarHospitalComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ListarBuscarHospitalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
