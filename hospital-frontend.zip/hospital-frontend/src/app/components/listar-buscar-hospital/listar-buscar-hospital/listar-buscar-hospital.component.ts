import { Component, OnInit } from '@angular/core';
import { HospitalsService } from '../../../services/hospitals.service';
import Swal from 'sweetalert2';
import { Router } from '@angular/router';

@Component({
  selector: 'app-listar-buscar-hospital',
  standalone: false,
  templateUrl: './listar-buscar-hospital.component.html',
  styleUrl: './listar-buscar-hospital.component.css'
})
export class ListarBuscarHospitalComponent implements OnInit {
  hospitales: any[] = []; // Lista de hospitales
  nombre: string = ''; // Filtro por nombre
  idGerente: number | null = null; // Filtro por ID Gerente
  idDistrito: number | null = null; // Filtro por ID Distrito
  idProvincia: number | null = null; // Filtro por ID Provincia
  loading: boolean = false; // Estado de carga


  constructor(private hospitalService: HospitalsService, private router: Router) {}

  ngOnInit(): void {
    // Cargar todos los hospitales al iniciar
    this.buscarHospitales();
  }

  /**
   * Buscar hospitales usando los filtros ingresados.
   */
  buscarHospitales(): void {
    this.loading = true;

    const filtros = {
      nombre: this.nombre,
      idGerente: this.idGerente || undefined,
      idDistrito: this.idDistrito || undefined,
      idProvincia: this.idProvincia || undefined,
    };

    this.hospitalService.buscarHospitales(filtros).subscribe({
      next: (data) => {
        this.hospitales = data;
        this.loading = false;
      },
      error: (err) => {
        console.error('Error al buscar hospitales:', err);
        this.loading = false;
      },
    });
  }
  ModificarHospital(idHospital: number): void {
      // Redirige al componente del formulario de actualización con el ID correspondiente
      this.router.navigate([`/hospitales/editar/${idHospital}`]);
    }
    eliminarHospital(id: number) {
      Swal.fire({
        title: '¿Estás seguro?',
        text: "Confirma si deseas eliminar el hospital",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Sí, elimínalo',
        cancelButtonText: 'No, cancelar',
        buttonsStyling: true
      }).then((result) => {
        console.log("Resultado del SweetAlert:", result); // 🟢 Verifica si se ejecuta
    
        if (result.isConfirmed) {
          console.log("Confirmación aceptada, llamando a eliminar..."); // 🟢 Verifica que entra al IF
    
          this.hospitalService.eliminarHospital(id).subscribe({
            next: (response) => {
              console.log("Respuesta del backend:", response); // 🟢 Verifica que el backend responde
              this.buscarHospitales();
              Swal.fire(
                'Hospital eliminado',
                response.message || 'El hospital ha sido eliminado con éxito', // Ahora usa la respuesta del backend
                'success'
              );
            },
            error: (err) => {
              console.error("Error al eliminar:", err);
              Swal.fire("Error", err.error?.error || "No se pudo eliminar el hospital", "error");
            }
          });
        }
      });
    };
    IrGestionHospitales() {
      this.router.navigate(['/home'])
    }
    RegistrarNuevoHospital() {
      this.router.navigate(['/registrar'])
    }
}


