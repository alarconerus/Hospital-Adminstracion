import { ComponentFixture, TestBed } from '@angular/core/testing';

import { ActualizarHospitalComponent } from './actualizar-hospital.component';

describe('ActualizarHospitalComponent', () => {
  let component: ActualizarHospitalComponent;
  let fixture: ComponentFixture<ActualizarHospitalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ActualizarHospitalComponent]
    })
    .compileComponents();

    fixture = TestBed.createComponent(ActualizarHospitalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
