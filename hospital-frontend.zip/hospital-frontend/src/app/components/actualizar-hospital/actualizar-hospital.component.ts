import { Component, OnInit } from '@angular/core';
import {HospitalsService} from '../../services/hospitals.service';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { Router, ActivatedRoute } from '@angular/router';
import Swal from 'sweetalert2';

@Component({
  selector: 'app-actualizar-hospital',
  standalone: false,
  templateUrl: './actualizar-hospital.component.html',
  styleUrl: './actualizar-hospital.component.css'
})
export class ActualizarHospitalComponent implements OnInit {
  hospitalForm!: FormGroup;
  idHospital!: number; // ID recibido desde la ruta
  hospitalEncontrado: boolean = true; // Para manejar errores de no encontrado

  constructor(
    private fb: FormBuilder,
    private hospitalService: HospitalsService,
    private route: ActivatedRoute,
    private router: Router
  ) {}

  ngOnInit(): void {
    // Inicializar el formulario vacío
    this.hospitalForm = this.fb.group({
      idDistrito: ['', Validators.required],
      nombre: ['', Validators.required],
      antiguedad: ['', [Validators.required, Validators.min(1)]],
      area: ['', [Validators.required, Validators.min(1)]],
      idSede: ['', Validators.required],
      idGerente: ['', Validators.required],
      idCondicion: ['', Validators.required]
    });

    // Obtener el ID del hospital desde la ruta
    this.idHospital = Number(this.route.snapshot.paramMap.get('id'));

    if (this.idHospital) {
      // Traer datos desde el backend
      this.hospitalService.listarHospitalPorId(this.idHospital).subscribe({
        next: (hospital) => {
          // Poner los datos en el formulario
          this.hospitalForm.patchValue(hospital);
        },
        error: () => {
          this.hospitalEncontrado = false; // Si hay un error, mostrar mensaje de error
        }
      });
    }
  }
   volverHome()
   {
      this.router.navigate(['/hospitales']);
   }

  actualizarHospital(): void {
    if (this.hospitalForm.valid) {
      // Construir el objeto para enviar
      const hospitalActualizado = this.hospitalForm.value;

      // Enviar los datos actualizados al backend
      this.hospitalService.actualizarHospital(this.idHospital, hospitalActualizado).subscribe({
        next: () => {
          Swal.fire({
            title: 'Hospital Actualizado',
            text: "El Hospital ha sido actualizado con exito",
            icon: 'success',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#white',
            confirmButtonText: 'ok',
            cancelButtonText: '',
            buttonsStyling: true
          });
          this.volverHome(); // Redirigir al listado tras actualizar
        },
        error: () => {
          alert('Error al actualizar el hospital');
        }
      });
    } else {
      alert('Por favor revisa los datos del formulario antes de guardar.');
    }
  }
  cancelar() {
    console.log('Cancelando y regresando al Home');
    this.router.navigate(['/hospitales']);
  }
  
}

  
