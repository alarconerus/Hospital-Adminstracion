import { Component } from '@angular/core';

import { MatSidenavModule } from '@angular/material/sidenav';
import { MatListModule } from '@angular/material/list';
import { RouterModule } from '@angular/router';
import { MatIconModule } from '@angular/material/icon'; // ✅ Importa MatIconModule
import { AuthService } from '../../../services/services/auth.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-sidebar',
  standalone: true,
  imports: [MatSidenavModule,MatIconModule, MatListModule, RouterModule], // ✅ Importa Angular Material y RouterModule
  templateUrl: './sidebar.component.html',
  styleUrl: './sidebar.component.css'
})
export class SidebarComponent {
  
  constructor(private authService: AuthService, private router: Router) {}

  logout() {
    this.authService.logout(); // Elimina el token
    this.router.navigate(['/login']); // Redirige al login
  }
}
