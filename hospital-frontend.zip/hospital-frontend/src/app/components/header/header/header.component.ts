import { Component, OnDestroy, OnInit } from '@angular/core';
import { AuthService } from '../../../services/services/auth.service';
import { Router } from '@angular/router';
import { MatIconModule } from '@angular/material/icon';
import { DatePipe } from '@angular/common';

@Component({
  selector: 'app-header',
  standalone: true,
  imports: [MatIconModule,DatePipe], // Import
  templateUrl: './header.component.html',
  styleUrl: './header.component.css'
})
export class HeaderComponent implements OnInit, OnDestroy  {
  
  currentDate: Date = new Date();
  private intervalId: any;

  constructor(private router: Router) {}

  ngOnInit(): void {
    // Actualiza la hora cada segundo
    this.intervalId = setInterval(() => {
      this.currentDate = new Date();
    }, 1000);
  }

  logout(): void {
    // Aquí puedes limpiar el token o la sesión del usuario
    localStorage.removeItem('token');
    this.router.navigate(['/login']); // Redirigir al login
  }

  ngOnDestroy(): void {
    // Limpia el intervalo al destruir el componente
    if (this.intervalId) {
      clearInterval(this.intervalId);
    }
  }
}