import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators, ReactiveFormsModule } from '@angular/forms';
import { HospitalsService } from '../../services/hospitals.service';
import { Router } from '@angular/router';
import { ListHospital } from '../../model/list-hospital';
import Swal from 'sweetalert2';
import { catchError, tap } from 'rxjs/operators';
import { throwError } from 'rxjs';
import { CommonModule } from '@angular/common';
import { MatInputModule } from '@angular/material/input';
import { MatButtonModule } from '@angular/material/button';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatIconModule } from '@angular/material/icon';
import { MatSelectModule } from '@angular/material/select';
@Component({
  selector: 'app-registrar-hospital',
  standalone: true,
  imports: [
    CommonModule, 
    ReactiveFormsModule,  // ✅ Se agregó para habilitar formGroup
    MatFormFieldModule, 
    MatInputModule, 
    MatButtonModule,
    MatIconModule,
    MatSelectModule
  ],
  templateUrl: './registrar-hospital.component.html',
  styleUrls: ['./registrar-hospital.component.css']
})
export class RegistrarHospitalComponent implements OnInit {
  hospitalForm!: FormGroup;

  sedes = [
    { id: 1, nombre: 'Sede Central' },
    { id: 2, nombre: 'Sede Regional' }
  ];
  gerentes = [
    { id: 1, nombre: 'Dr.Juan Perez' },
    { id: 2, nombre: 'Dra. Maria López' }
  ];
  condiciones = [
    { id: 1, nombre: 'Operativo' },
    { id: 2, nombre: 'Mantenimiento' }
  ];
  distritos = [
    { id: 1, nombre: 'Miraflores' },
    { id: 2, nombre: 'San Isidro' },
    { id: 3, nombre: 'Cuzco Centro' }
  ];

  constructor(
    private fb: FormBuilder,
    private hospitalService: HospitalsService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.hospitalForm = this.fb.group({
      nombre: ['', Validators.required],
      antiguedad: [0, [Validators.required, Validators.min(0)]],
      area: [0, [Validators.required, Validators.min(0)]],
      idSede: [0, Validators.required],
      idGerente: [0, Validators.required],
      idCondicion: [0, Validators.required],
      idDistrito: [0, Validators.required],
    });
  }

  onSubmit() {
    if (this.hospitalForm.valid) {
      console.log('Enviando hospital:', this.hospitalForm.value);

      this.hospitalService.registrarHospital(this.hospitalForm.value).pipe(
        catchError((error) => {
          console.error('Error en la solicitud:', error);
          Swal.fire('Error', 'Hubo un problema al registrar el hospital', 'error');
          return throwError(error);
        })
      ).subscribe({
        next: (response) => {
          console.log('Respuesta del servidor:', response);
          Swal.fire({
            title: 'Éxito',
            text: response.message,  // ✅ Ahora usa el mensaje del backend
            icon: 'success',
            confirmButtonText: ' Aceptar '
            
          }).then(() => {
            this.irhome();
          });
        }
      });
    }
  }

  cancelar() {
    console.log('Cancelando y regresando al Home');
    this.router.navigate(['/hospitales']);
  }
  irhome() {
    this.router.navigate(['/hospitales']);
  }
}