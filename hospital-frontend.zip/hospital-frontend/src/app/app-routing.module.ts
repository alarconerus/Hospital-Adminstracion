import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { HomeComponent } from './pages/home/home.component';
import { LoginComponent } from './pages/login/login.component';
import { ListarBuscarHospitalComponent } from './components/listar-buscar-hospital/listar-buscar-hospital/listar-buscar-hospital.component';
import { RegistrarHospitalComponent } from './components/registrar-hospital/registrar-hospital.component';
import { ActualizarHospitalComponent } from './components/actualizar-hospital/actualizar-hospital.component';


const routes: Routes = [
  { path: 'login', component: LoginComponent },
  
     { path: 'login', component: LoginComponent },
     { path: 'home', component: HomeComponent }, // ✅ Asegurar que esté bien importado
     { path: 'hospitales/editar/:id', component: ActualizarHospitalComponent }, // Ruta para actualizar hospitales
     { path: '', redirectTo: 'login', pathMatch: 'full' }, // Redirección inicial
     { path: 'hospitales', component: ListarBuscarHospitalComponent },
     { path: 'registrar', component: RegistrarHospitalComponent}

];


 


@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
