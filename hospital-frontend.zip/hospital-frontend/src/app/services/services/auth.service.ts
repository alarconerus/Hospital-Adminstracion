import { Injectable } from '@angular/core';


import { HttpClient } from '@angular/common/http';
import { Observable } from 'rxjs';
import { map } from 'rxjs/operators';

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  private apiUrl = 'http://localhost:8080/api/auth/login'; // URL del backend
  private TOKEN_KEY = 'auth_token'; // Clave para almacenar el token en localStorage

  constructor(private http: HttpClient) { }
  login(username: string, password: string): Observable<string> {
    // Se usa directamente apiUrl, sin '/login'
    return this.http.post(this.apiUrl, { username, password }, { responseType: 'text' })
      .pipe(map(token => token.trim())); // Elimina posibles espacios en blanco del token
  }


  saveToken(token: string): void {
    if (typeof window !== 'undefined') {
      localStorage.setItem(this.TOKEN_KEY, token);
    }
  }

  getToken(): string | null {
    if (typeof window !== 'undefined') {
      return localStorage.getItem(this.TOKEN_KEY);
    }
    return null;
  }

  removeToken(): void {
    if (typeof window !== 'undefined') {
      localStorage.removeItem(this.TOKEN_KEY);
    }
  }
  logout() {
    localStorage.removeItem('token'); // Elimina el token
    localStorage.removeItem('user');  // Opcional: eliminar otros datos del usuario
  }
}
