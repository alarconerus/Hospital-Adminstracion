import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { ListHospital } from '../model/list-hospital';

@Injectable({
  providedIn: 'root',
})
export class HospitalsService {
  private readonly baseUrl = 'http://localhost:8080/api/hospitales';

  constructor(private http: HttpClient) {}

  // Obtener todos los hospitales
  getHospitales(): Observable<any[]> {
    return this.http.get<any[]>(`${this.baseUrl}/listar`);
  }

  // Eliminar un hospital
  eliminarHospital(id: number): Observable<{ message?: string; error?: string }> {
    return this.http.delete<{ message?: string; error?: string }>(`${this.baseUrl}/eliminar/${id}`);
  }

  // Obtener hospital por ID
  listarHospitalPorId(id: number): Observable<any> {
    return this.http.get<any>(`${this.baseUrl}/${id}`);
  }

  // Actualizar hospital
  actualizarHospital(id: number, hospital: any): Observable<any> {
    return this.http.put<any>(`${this.baseUrl}/actualizar/${id}`, hospital);
  }

  // Registrar hospital
  registrarHospital(hospital: any): Observable<any> {
    return this.http.post<any>(`${this.baseUrl}/registrar`, hospital);
  }

  /**
   * Buscar hospitales mediante filtros.
   * @param filtros Un objeto con las claves nombre, idGerente, idDistrito o idProvincia.
   */
  buscarHospitales(filtros: {
    nombre?: string;
    idGerente?: number;
    idDistrito?: number;
    idProvincia?: number;
  }): Observable<any[]> {
    let params = new HttpParams();
    
    Object.entries(filtros).forEach(([key, value]) => {
      if (value !== undefined) params = params.set(key, value.toString());
    });

    return this.http.get<any[]>(`${this.baseUrl}/buscar`, { params });
  }

  // Método adicional para actualizar hospital (parece un duplicado)
  actualizarHospitalV2(id: number, hospital: ListHospital): Observable<Object> {
    return this.http.put(`${this.baseUrl}/actualizar/${id}`, hospital);
  }
}
