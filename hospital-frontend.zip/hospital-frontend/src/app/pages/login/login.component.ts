import { Component } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';

import { AuthService } from '../../services/services/auth.service';
import { Router } from '@angular/router';


@Component({
  selector: 'app-login',
  standalone: false,
  templateUrl: './login.component.html',
  styleUrl: './login.component.css'
})
export class LoginComponent {
  loginForm: FormGroup;
  hidePassword = true;
  errorMessage: string = ''; // Definir variable para manejar errores

  constructor(private fb: FormBuilder,
              private authService: AuthService, // Inyectar el servicio de autenticación
              private router: Router // Inyectar el router para la navegación
  ) {
    this.loginForm = this.fb.group({
      username: ['', Validators.required],
      password: ['', Validators.required]
    });
  }

  onLogin() {
    if (this.loginForm.valid) {
      const { username, password } = this.loginForm.value;
      this.authService.login(username, password).subscribe(
        (token: string) => {
          this.authService.saveToken(token);
          this.router.navigate(['/home']); // Redirige a la página de hospitales
        },
        (error) => {
          this.errorMessage = 'Credenciales incorrectas';
          console.error('Error en el login', error);
        }
      );
    }
  }
}