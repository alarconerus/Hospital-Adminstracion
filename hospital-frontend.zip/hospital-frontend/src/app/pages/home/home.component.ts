import { Component } from '@angular/core';
import { SidebarComponent } from '../../components/sidebar/sidebar/sidebar.component'; 
import { HeaderComponent } from '../../components/header/header/header.component'; 
import { RouterModule } from '@angular/router';
import { CommonModule } from '@angular/common';

@Component({
  selector: 'app-home',
  standalone: true,  //
  imports: [CommonModule, RouterModule, SidebarComponent, HeaderComponent,  ], 
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent {
  isOpened = true;
  
}
