import { ListHospital } from './list-hospital';

describe('ListHospital', () => {
  it('should create an instance', () => {
    expect(new ListHospital()).toBeTruthy();
  });
});
