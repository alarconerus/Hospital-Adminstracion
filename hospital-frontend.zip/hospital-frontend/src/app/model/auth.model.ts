//usando esto como si fuera un entidad que obtendra los datos para login
export interface LoginRequest {
    username: string;
    password: string;
  }
  
  export interface AuthResponse {
    token: string;
  }