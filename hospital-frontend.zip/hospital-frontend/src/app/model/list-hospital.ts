//para todos las demas operaciones de crud
export class ListHospital {
    idHospital?: number; // ? significa que es opcional
    nombre: string = '';
    antiguedad: number = 0;
    area: number = 0;
    idSede: number = 0;
    idGerente: number = 0;
    idCondicion: number = 0;
    idDistrito: number = 0;
    descProvincia: string = '';  
  }