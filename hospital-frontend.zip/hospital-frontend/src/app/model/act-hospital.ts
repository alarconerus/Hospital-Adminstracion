//para actualizar hospital
export class ActHospital {
    idHospital: number = 0; // ? significa que es opcional
    nombre: string = '';
    antiguedad: number = 0;
    area: number = 0;
    idSede: number = 0;
    idGerente: number = 0;
    idCondicion: number = 0;
    idDistrito: number = 0;
    
  }